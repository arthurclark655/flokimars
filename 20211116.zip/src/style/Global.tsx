import { createGlobalStyle } from 'styled-components'
// eslint-disable-next-line import/no-unresolved
import { PancakeTheme } from '@pancakeswap-libs/uikit'

declare module 'styled-components' {
  /* eslint-disable @typescript-eslint/no-empty-interface */
  export interface DefaultTheme extends PancakeTheme {}
}

const GlobalStyle = createGlobalStyle`
  * {
    font-family: inherit;
  }
  @font-face {
    font-family: "Mitr";
    src: url(/fonts/mitr/MitrRegular400.ttf);
  }  
  @font-face {
    font-family: "Futura_Bold";
    src: url(/fonts/mitr/Futura Bold font.ttf);
  } 
  @font-face {
    font-family: "Blade Runner";
    src: url(/fonts/blade/BLADRMF_.TTF);
  } 
  body {
    background-color: ${({ theme }) => theme.colors.background};
    font-family: Mitr;

    img {
      height: auto;
      max-width: 100%;
    }
  }
  .fa, .fas {
    font-family: "Font Awesome 5 Pro";
    font-weight: 900;
  }
  .fa-check-circle:before {
    content: "\f058";
  }
  .align-bottom {
    vertical-align: bottom;
  }
  .TVLChart {
    > canvas {
      height: 200px !important;
    }
  }
  .inline-block {
    display: flex;
  }
  .info {
    display: flex;
    flex-direction: column;
    width: 100%;
    
    @media (max-width:676px){
      flex-direction: row;
      justify-content: space-between
    }
  }
  .imgBtn{
    @media (max-width:676px){
      margin-top: 10px;
    }
  }
  article{
    width: 100%;
    height: calc(100vh - 150px) !important;
  }
`

export default GlobalStyle
