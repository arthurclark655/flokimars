import { MenuEntry } from '@pancakeswap-libs/uikit'

const config: MenuEntry[] = [
  {
    label: 'Home',
    icon: 'HomeIcon',
    href: '/',
  },
  {
    label: 'Staking',
    icon: 'FarmIcon',
    href: '/pools',
  },
  // {
  //   label: 'Pools',
  //   icon: 'PoolIcon',
  //   href: '/pools',
  // },
  // {
  //   label: 'DEX',
  //   icon: 'TradeIcon',
  //   items: [
  //     {
  //       label: 'Exchange',
  //       href: 'https://exchange.pancakeswap.finance/#/swap?inputCurrency=0x399B091aDfeEe715460e31EF1Ff76FfcFC1eFDa9&outputCurrency=BNB',
  //     },
  //     {
  //       label: 'Liquidity',
  //       href: 'https://exchange.pancakeswap.finance/#/add/0x399B091aDfeEe715460e31EF1Ff76FfcFC1eFDa9/BNB',
  //     },
  //   ],
  // }, 
  // {
  //   label: 'Chart',
  //   icon: 'InfoIcon',
  //   href: '/tradingchart',
  // },
  // {
  //   label: 'Jungles',
  //   icon: 'JungleIcon',
  //   href: '/craters',
  // },
  // {
  //   label: 'Lottery',
  //   icon: 'TicketIcon',
  //   href: '',
  // },
  // {
  //   label: 'Refferals',
  //   icon: 'GroupsIcon',
  //   href: '',
  // },
  // {
  //   label: "Audits",
  //   icon: "AuditIcon",
  //   href: ""
  // },
  
  // {
  //   label: 'IDO',
  //   icon: 'ListingIcon',
  //   items: [
  //     // {
  //     //   label: 'BscScan',
  //     //   href: 'https://bscscan.com/address/0x8d9087a2B7E446bb69343542e1430E974f12a18F',
  //     // },
  //   ],
  // },
  // {
  //   label: 'Features',
  //   icon: 'PriceGuardIcon',
  //   items: [
  //     // {
  //     //   label: 'Automatic LP',
  //     //   href: 'https://docs.moonharvest.net/untitled-1',
  //     // },
  //     // {
  //     //   label: 'Automatic Burning',
  //     //   href: 'https://docs.moonharvest.net/automatic-burning',
  //     // },
  //     // {
  //     //   label: 'Referral Program',
  //     //   href: 'https://docs.moonharvest.net/referral-program',
  //     // },
  //     // {
  //     //   label: 'Anti Whale',
  //     //   href: 'https://docs.moonharvest.net/anti-whale',
  //     // },
  //   ],
  // },
 
  {
    label: 'More',
    icon: 'MoreIcon',
    items: [
      {
        label: 'Github',
        href: 'https://github.com/FlokiMars',
      },
      {
        label: 'Docs',
        href: 'http://flokimars.io/litepaper.pdf',
      },
      {
        label: 'Reddit',
        href: 'https://www.reddit.com/user/FlokiMars',
      },
      {
        label: 'Blog',
        href: 'https://flokimars.medium.com',
      },
    ],
  },
  
]

export default config
