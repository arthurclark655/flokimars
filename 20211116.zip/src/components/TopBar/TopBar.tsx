import React, { useContext } from 'react'
import styled, { ThemeContext } from 'styled-components'

const TopBar: React.FC = () => {
  const theme = useContext(ThemeContext)
  return (
    <StyledTopBar>
      <StyledHeader>FLOKI MARS</StyledHeader>
    </StyledTopBar>
  )
}

const StyledTopBar = styled.div`
  height: 150px;
  width: 100%;
  background-size: 100% auto;
  background-position: top;
  background-repeat: no-repeat;
  position: relative;
  
  z-index: 1;
  @media (max-width: 767px) {
    background-size: auto 100%;
    background-position: center;
    padding-top: 100px;
    > div{
      font-size: 24px !important;
    }
  }
`
const StyledHeader = styled.div`
  background-color: white;
  //  background-image: linear-gradient(0deg, ${({theme}) => theme.colors.primary}, ${({theme}) => theme.colors.primaryBright});
  background-size: 100%;
  background-repeat: repeat;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent; 
  -moz-background-clip: text;
  -moz-text-fill-color: transparent;

  font-size: 60px;
  text-align: center;
  font-family:"Poppins-Medium";
  padding-top: 24px;
  @media (min-width: 767px) {
    margin-left: -10%;
    text-align: center;
  }
`

export default TopBar
