import BigNumber from 'bignumber.js'
import React, { useCallback, useState } from 'react'
import styled from 'styled-components'
import { AddIcon, Button, IconButton, useModal, Flex, Link, Text, Skeleton } from '@pancakeswap-libs/uikit'
import { useWallet } from '@binance-chain/bsc-use-wallet'
import UnlockButton from 'components/UnlockButton'
import Label from 'components/Label'
import { useERC20 } from 'hooks/useContract'
import { useSousApprove } from 'hooks/useApprove'
import useI18n from 'hooks/useI18n'
import { useSousStake } from 'hooks/useStake'
import { useSousUnstake } from 'hooks/useUnstake'
import { useFlokimarsLPBnbamount, useFlokimarsLPTokenamount } from 'hooks/useTokenBalance'
import { getBalanceNumber } from 'utils/formatBalance'
import { useSousHarvest } from 'hooks/useHarvest'
import { useGetPrice } from 'hooks/api'
import Balance from 'components/Balance'
import { PoolCategory, QuoteToken } from 'config/constants/types'
import { Pool } from 'state/types'
import ExpandableSectionButton from 'components/ExpandableSectionButton'
import { BLOCKS_PER_YEAR } from 'config'
import DepositModal from './DepositModal'
import WithdrawModal from './WithdrawModal'
import Card from './Card'
import HarvestButton from './HarvestButton'




interface PoolWithApy extends Pool {
  apy: BigNumber
}

interface HarvestProps {
  pool: PoolWithApy
}

const PoolCard: React.FC<HarvestProps> = ({ pool }) => {
  const {
    sousId,
    image,
    tokenName,
    stakingTokenName,
    stakingTokenAddress,
    projectLink,
    harvest,
    apy,
    tokenDecimals,
    poolCategory,
    totalStaked,
    // startBlock,
    // endBlock,
    isFinished,
    userData,
    stakingLimit,
    burnFee
  } = pool

  // console.log("sousId", sousId)
  // console.log("totalStaked", totalStaked)

  const [showExpandableSection, setShowExpandableSection] = useState(false);
  const typeImage = sousId;

   
  // Pools using native BNB behave differently than pools using a token
  const isBnbPool = poolCategory === PoolCategory.BINANCE
  const TranslateString = useI18n()
  const stakingTokenContract = useERC20(stakingTokenAddress)
  const { account } = useWallet()
  // const block = useBlock()
  const { onApprove } = useSousApprove(stakingTokenContract, sousId)
  const { onStake } = useSousStake(sousId)
  const { onUnstake } = useSousUnstake(sousId)
  const { onReward } = useSousHarvest(sousId)

  const [requestedApproval, setRequestedApproval] = useState(false)
  const [pendingTx, setPendingTx] = useState(false)

  const allowance = new BigNumber(userData?.allowance || 0)
  const stakingTokenBalance = new BigNumber(userData?.stakingTokenBalance || 0)
  const stakedBalance = new BigNumber(userData?.stakedBalance || 0)
  const earnings = new BigNumber(userData?.pendingReward || 0)
   
  const accountHasStakedBalance = stakedBalance?.toNumber() > 0
  const needsApproval = !accountHasStakedBalance && !allowance.toNumber() && !isBnbPool
  const isCardActive = isFinished && accountHasStakedBalance

  const convertedLimit = new BigNumber(stakingLimit).multipliedBy(new BigNumber(10).pow(tokenDecimals))
  const [onPresentDeposit] = useModal(
    <DepositModal
      max={stakingLimit && stakingTokenBalance.isGreaterThan(convertedLimit) ? convertedLimit : stakingTokenBalance}
      onConfirm={onStake}
      tokenName={stakingLimit ? `${stakingTokenName} (${stakingLimit} max)` : stakingTokenName}
      burnFeeBP={burnFee * 10}
    />,
  )

  const [onPresentWithdraw] = useModal(
    <WithdrawModal max={stakedBalance} onConfirm={onUnstake} tokenName={stakingTokenName} />,
  )

  const handleApprove = useCallback(async () => {
    try {
      setRequestedApproval(true)
      const txHash = await onApprove()
      // user rejected tx or didn't go thru
      if (!txHash) {
        setRequestedApproval(false)
      }
    } catch (e) {
      console.error(e)
    }
  }, [onApprove, setRequestedApproval])

  const bnbprice = useGetPrice()
  const price = bnbprice === null? 0:bnbprice.price
  
  const lpBnb = useFlokimarsLPBnbamount();  
  const lpBnbamount = lpBnb.toNumber()

  const lpFlokimars = useFlokimarsLPTokenamount();  
  const lpFlokimarsamount = lpFlokimars.toNumber()

  const flokimarsPrice = lpBnbamount*price/lpFlokimarsamount;

  const totalStakedAmount = new BigNumber(totalStaked);  
  const totalAmount1 = totalStakedAmount.toNumber()
  const totalAmount = totalAmount1 < 10 ? 0:totalAmount1  

  let tokenPrice = 0;
  if(sousId === 0) {
    tokenPrice = flokimarsPrice;
  } else if(sousId === 1) {
    tokenPrice = price;
  } else if(sousId === 2) {
    tokenPrice = 1;
  }

  const flokimarsTotalStaked = totalAmount*tokenPrice/10**18;

  const bpy = BLOCKS_PER_YEAR.toNumber()

  const poolapy = totalAmount === 0 ? 0: (bpy*100*10**18*69400000*flokimarsPrice/(totalAmount*tokenPrice)).toFixed(2)
  
 
  return (
    <Card isActive={isCardActive} isFinished={isFinished && sousId !== 0}>
      {isFinished && sousId !== 0 && <PoolFinishedSash />}     

      <PoolCardHeader onClick={() => setShowExpandableSection(!showExpandableSection)}>
        <IndicatorIcon>
          <img src={`/images/${typeImage}.png`} alt={`${typeImage}`} style={{height:"25px"}}/>
        </IndicatorIcon>
        <EarnInfo>          
          <Flex>
            <LPImage>
              <img src={`/images/tokens/${stakingTokenName}.png`} alt={tokenName} />
            </LPImage>
            <div>
            <img src='/images/arrowIcon.png' alt={tokenName} style={{height:"50px"}}/>
            </div>
            <LPImage>
              <img src='/images/flokimarsIcon.png' alt={tokenName} />
            </LPImage>
          </Flex>
          <EarnInfoText>
            <LPLabel>Stake ${stakingTokenName}</LPLabel>
            {/* <EarnLabel>Earn {earnLabel}</EarnLabel> */}
            <EarnLabel>Earn $FLOKIMARS</EarnLabel>
          </EarnInfoText>
        </EarnInfo>
        <AprTvl>
          <APRInfo>
            <InfoLabel>APR</InfoLabel>
            <InfoValue>{isFinished || !apy || apy?.isNaN() || !apy?.isFinite() ? (
                  <>
                    {poolapy}%
                  </>
                ) : (
                  <Skeleton height={24} width={80} />
                )}
            </InfoValue>
          </APRInfo>
          <TVLInfo>
            <InfoLabel>TVL</InfoLabel>
            <InfoValue>{isFinished || !apy || apy?.isNaN() || !apy?.isFinite() ? (
                  <>                    
                    ${flokimarsTotalStaked === null?"$0":flokimarsTotalStaked.toFixed(3)}
                  </>
                ) : (
                  <Skeleton height={24} width={80} />
                )}
            </InfoValue>
          </TVLInfo>
        </AprTvl>
        <ExpandableSectionButton
          onClick={() => setShowExpandableSection(!showExpandableSection)}
          expanded={showExpandableSection}
        />
      </PoolCardHeader>   

      <ExpandingWrapper expanded={showExpandableSection} className='w3-animate-opacity'>
        <Wrapper>
          <BalanceContainer> 
            <BalanceAndCompound>
              <Text style={{fontSize: '20px', padding: '10px', textAlign: 'center'}}>
                Rewards Earned
              </Text>
              <Balance value={getBalanceNumber(earnings, tokenDecimals)} isDisabled={isFinished} style={{textAlign: 'center'}}/>              
            </BalanceAndCompound>        
            <HarvestBtnContainer>
              {account && harvest && (
                <HarvestButton
                  disabled={!earnings.toNumber() || pendingTx}
                  text={pendingTx ? 'Collecting' : 'Harvest'}
                  onClick={async () => {
                    setPendingTx(true)
                    await onReward()
                    setPendingTx(false)
                  }}
                />
              )}
            </HarvestBtnContainer>                  
          </BalanceContainer>
          
          <Label isFinished={isFinished && sousId !== 0} text={TranslateString(330, `${tokenName} earned`)} />
          <StyledCardActions>
            {!account && <UnlockButton />}
            {account &&
              (needsApproval ? (
                <div style={{ flex: 1 }}>
                  <Button disabled={isFinished || requestedApproval} onClick={handleApprove} fullWidth>
                  {/* <Button disabled={isFinished || requestedApproval} fullWidth> */}
                    {`Approve ${stakingTokenName}`}
                  </Button>
                </div>
              ) : (
                <>
                  <Button
                    style={ActionBtnStyle}
                    disabled={stakedBalance.eq(new BigNumber(0)) || pendingTx}
                    onClick={                      
                        //  async () => {
                        //     setPendingTx(true)
                        //     await onUnstake('0')
                        //     setPendingTx(false)
                        //   }    
                        onPresentWithdraw                    
                    }
                  >
                    Unstake
                  </Button>
                  <StyledActionSpacer />                  
                  <Button 
                    style={ActionBtnStyle}
                    disabled={isFinished && sousId !== 0} onClick={onPresentDeposit}>
                    Stake
                  </Button>                  
                </>
              ))}
          </StyledCardActions>          
          
          <StyledDetails>
            <div style={{ flex: 1 }}>              
              <Text>                
                {TranslateString(384, 'Your Stake')}:
              </Text>
            </div>
            <Balance fontSize="14px" isDisabled={isFinished} value={getBalanceNumber(stakedBalance)} />
          </StyledDetails>
          {!isFinished && (
            <Flex justifyContent="space-between">
              <Text>{TranslateString(23, 'Total Liquidity')}:</Text>
              <Text>${flokimarsTotalStaked === null?"$0":flokimarsTotalStaked.toFixed(3)}</Text>
            </Flex>
          )}
          <Flex justifyContent="center">
            <Link external 
            // href={bscScanAddress} 
            href='https://bscscan.com/address/0x399b091adfeee715460e31ef1ff76ffcfc1efda9#code'
            bold={false}>
              <Text>{TranslateString(356, 'View on BscScan')}</Text>
            </Link>
          </Flex>
        </Wrapper>          
      </ExpandingWrapper>                
      
    </Card>
  )
}

const PoolFinishedSash = () => {
 return (
   <PoolFinishedSashDiv>
     <img src='/images/pool-finished-sash.svg' alt='pool-finished' style={{width: '100%'}}/>
   </PoolFinishedSashDiv>
 )
};

const PoolCardHeader = styled.div`
  cursor: pointer;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  ${({ theme }) => theme.mediaQueries.sm}{
    background-size: 100% 485px;
  }
  ${({ theme }) => theme.mediaQueries.xs} {
    background-size: 100% 510px;
  }
  text-align: center;
`
const ActionBtnStyle = {width: '200px', display: 'block', margin: 'auto'};

const LPImage = styled.div`
  margin: auto;
  padding: 0px 10px;
  > img {
    height:40px;
    // width:40px;
  }
`

const EarnLabel = styled.div`
  margin-top:15px;
  text-align: left;
  // color:${({theme}) => theme.colors.textDisabled}
  color:#ffa200;
`
const AprTvl = styled.div`
  width: 30%;
  display: flex;
  flex-direction: row;
  @media (max-width: 768px) {
    width: auto;
    display: block;
    flex-direction: column;
    margin-top: 30px;
    text-align: left;
  }
`
const APRInfo = styled.div`
  display: flex;
  flex-direction: column;
  flex: 1 1 0%;
  margin-left: auto;
  text-align: left;
  @media (max-width: 768px) {
    flex-direction: row;
  }
`
const TVLInfo = styled.div`
  display: flex;
  flex-direction: column;
  flex: 1 1 0%;
  margin-left: auto;
  text-align: left;
  @media (max-width: 768px) {
    flex-direction: row;
    margin-top:20px;
  }
`
const InfoLabel = styled.div`
  font-size: 18px;
  color:${({theme}) => theme.colors.primary};
  text-align: left;
  @media (max-width: 768px) {
    margin-right: 10px;
  }
`
const InfoValue = styled.div`
  margin-top:15px;
  color:${({theme}) => theme.colors.text};
  text-align: left;
  @media (max-width: 768px) {
    margin-top:2px;
  }
`

const LPLabel = styled.div`
  font-size: 23px;
  text-align: left;
  // color:${({theme}) => theme.colors.text}
  color:#FFFFFF;
`
const EarnInfo = styled.div`
  width: 50%;
  display: flex;
  @media (min-width: 768px){
    min-width: 300px;
  }
  @media (max-width: 768px) {
    flex-direction: column;
  }
`

const EarnInfoText = styled.div`
  display: flex;
  flex-direction: column;
  
`

const PoolFinishedSashDiv = styled.div`
  height: 90px;
  position: absolute;
  right: -15px;
  top: -15px;
  width: 90px;
`

const StyledCardActions = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: center;
  margin: 16px 0;
  width: 100%;
  box-sizing: border-box;
  @media (max-width: 768px) {
    flex-direction: column;
  }
`

const StyledActionSpacer = styled.div`
  height: ${(props) => props.theme.spacing[4]}px;
  width: ${(props) => props.theme.spacing[4]}px;
`

const StyledDetails = styled.div`
  display: flex;
  font-size: 14px;
`

const BalanceContainer = styled.div`
  display: flex;
  flex-direction: row;
  margin-bottom: 8px;
  @media (max-width: 768px) {
    flex-direction: column;
  }
`;

const BalanceAndCompound = styled.div`
  width: 70%;
  display: flex;
  flex-direction: row;
  @media (max-width: 768px) {
    display: flex;
    justify-content: center;
    width: 100%;
    flex-direction: column;
  }
`;

const HarvestBtnContainer = styled.div`
  width: 30%;
  padding: 10px;
  display: flex;
  justify-content: flex-end;
  @media (max-width: 768px) {
    justify-content: center;
    width: 100%;
  }
`;

const ExpandingWrapper = styled.div<{ expanded: boolean }>`  
  display: ${(props) => (props.expanded ? 'block' : 'none')};
  overflow: hidden;
  padding: 24px;
  padding-top: 0;
`;


const Wrapper = styled.div`
  padding-top: 24px;
  border-top: 0.5px solid ${({theme}) => theme.colors.textDisabled};
  margin: 24px 150px;
  @media (max-width:676px){
    margin: 14px 10px;
  }
`;

const IndicatorIcon = styled.div`
  position: absolute;
  left: 25px;
  top: -13px;
`;

export default PoolCard
