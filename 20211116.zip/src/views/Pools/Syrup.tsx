import React, {useState} from 'react'
import { Route, useRouteMatch, Link } from 'react-router-dom'
import BigNumber from 'bignumber.js'
import styled from 'styled-components'
import { useWallet } from '@binance-chain/bsc-use-wallet'
import { ButtonMenu, ButtonMenuItem, Toggle, Text } from '@pancakeswap-libs/uikit'
import { BLOCKS_PER_YEAR } from 'config'
import orderBy from 'lodash/orderBy'
import partition from 'lodash/partition'
import useI18n from 'hooks/useI18n'
import useBlock from 'hooks/useBlock'
import Select, { OptionProps } from 'components/Select/Select'
import { getBalanceNumber } from 'utils/formatBalance'
import { useFarms, usePools, usePriceBnbBusd } from 'state/hooks'
import { PoolCategory, QuoteToken } from 'config/constants/types'
// import FlexLayout from 'components/layout/Flex'
import Page from 'components/layout/Page'
// import Coming from './components/Coming'
import PoolCard from './components/PoolCard'

const Farm: React.FC = () => {
  const { url, isExact } = useRouteMatch();
  const TranslateString = useI18n()
  const { account } = useWallet()
  const farms = useFarms()
  const pools = usePools(account)
  const bnbPriceUSD = usePriceBnbBusd()
  const block = useBlock()
  const [deposited, setDeposited] = useState(true);
  const [typeOption, setTypeOption] = useState('all');

  const handleTypeOptionChange = (option: OptionProps): void => {
    setTypeOption(option.value)
  }  

  const priceToBnb = (tokenName: string, tokenPrice: BigNumber, quoteToken: QuoteToken): BigNumber => {
    const tokenPriceBN = new BigNumber(tokenPrice)
    if (tokenName === 'BNB') {
      return new BigNumber(1)
    }
    if (tokenPrice && quoteToken === QuoteToken.BUSD) {
      return tokenPriceBN.div(bnbPriceUSD)
    }
    return tokenPriceBN
  }

  const poolsWithApy = pools.map((pool) => {
    const isBnbPool = pool.poolCategory === PoolCategory.BINANCE
    const rewardTokenFarm = farms.find((f) => f.tokenSymbol === pool.tokenName)
    const stakingTokenFarm = farms.find((s) => s.tokenSymbol === pool.stakingTokenName)

    // /!\ Assume that the farm quote price is BNB
    const stakingTokenPriceInBNB = isBnbPool ? new BigNumber(1) : new BigNumber(stakingTokenFarm?.tokenPriceVsQuote)
    const rewardTokenPriceInBNB = priceToBnb(
      pool.tokenName,
      rewardTokenFarm?.tokenPriceVsQuote,
      rewardTokenFarm?.quoteTokenSymbol,
    )

    const totalRewardPricePerYear = rewardTokenPriceInBNB.times(pool.tokenPerBlock).times(BLOCKS_PER_YEAR)
    const totalStakingTokenInPool = stakingTokenPriceInBNB.times(getBalanceNumber(pool.totalStaked))
    const apy = totalRewardPricePerYear.div(totalStakingTokenInPool).times(100)

    return {
      ...pool,
      isFinished: pool.sousId === 0 ? false : pool.isFinished || block > pool.endBlock,
      apy,
    }
  })

  const renderPools = () => {
    
    let [finishedPools, openPools] = partition(poolsWithApy, (pool) => pool.isFinished);

    // Filter by deposited
    // if(deposited) {
    //   openPools = openPools.filter(pool => {
    //     const {userData} = pool;
    //     return userData && Number(userData.stakedBalance) > 0;
    //   });
    // } else {
    //   openPools = openPools.filter(pool => {
    //     const {userData} = pool;
    //     return userData && Number(userData.stakedBalance) === 0;
    //   });
    // }

    // Filter by typeOption
    if(typeOption === 'all') {
      openPools = {...openPools};
      finishedPools = {...finishedPools};
    } else if(typeOption === 'single') {
      openPools = openPools.filter(pool => {
        return pool.sousId === 0 || pool.sousId === 1 || pool.sousId === 2;
      });
      finishedPools = finishedPools.filter(pool => {
        return pool.sousId === 0 || pool.sousId === 1 || pool.sousId === 2;
      });
    } else {
      openPools = openPools.filter(pool => {
        return pool.sousId === 3 || pool.sousId === 4 || pool.sousId === 5;
      });
      finishedPools = finishedPools.filter(pool => {
        return pool.sousId === 3 || pool.sousId === 4 || pool.sousId === 5;
      });
    }

    return (
      <>
        <Route exact path={`${url}`}>
          {orderBy(openPools, ['sortOrder']).map((pool) => (
            <PoolCard key={pool.sousId} pool={pool} />
          ))}
          {/* <Coming />          */}
        </Route>
        <Route path={`${url}/history`}>
          {orderBy(finishedPools, ['sortOrder']).map((pool) => (
            <PoolCard key={pool.sousId} pool={pool} />
          ))}
        </Route>
      </>
    );
  };

  // console.log(openPools);
  return (
    <Page>
      <PoolsContainer className='w3-animate-opacity'>        
        <Hero>
          {/* <TotalValueLocked>
            <HeadingLabel>
              TOTAL VALUE LOCKED
            </HeadingLabel>
            <HeadingValue>
              $0
            </HeadingValue>
          </TotalValueLocked> */}
          <div className='w3-row'>
            <div className='w3-col m6'>
              <ViewControls>
                <ButtonMenu activeIndex={isExact ? 0 : 1} size="sm" variant="primary">
                  <ButtonMenuItem as={Link} to={`${url}`}>
                    Active
                  </ButtonMenuItem>
                  <ButtonMenuItem as={Link} to={`${url}/history`}>
                  {/* <ButtonMenuItem as={Link} > */}
                    Inactive
                  </ButtonMenuItem>
                </ButtonMenu>
                {/* <ToggleWrapper>
                  <Toggle checked={deposited} onChange={() => setDeposited(!deposited)} />  
                  <Text style={{marginLeft: '30px'}}> Deposited</Text>                
                </ToggleWrapper> */}
              </ViewControls>
            </div> 
            <div className='w3-col m6'>
              <FilterContainer>
                <LabelWrapper>
                  <Text style={{margin: "auto 10px"}}>Type</Text>
                  <Select
                    options={[
                      {
                        label: "All",
                        value: 'all',
                      },
                      {
                        label: 'Locked Farm',
                        value: 'farm',
                      },
                      {
                        label: 'Single Asset',
                        value: 'single',
                      }
                    ]}
                    onChange={handleTypeOptionChange}
                  />
                </LabelWrapper>            
              </FilterContainer>
            </div>            
          </div>
        </Hero>
        <PoolCardsContainer>
          {renderPools()}
        </PoolCardsContainer>
      </PoolsContainer>      
    </Page>
  )
}

const PoolsContainer = styled.div`
  max-width: 1140px;
  margin: 0 auto;
`;

const Hero = styled.div`
  align-items: center;
  color: ${({ theme }) => theme.colors.primary};
  grid-gap: 32px;
  grid-template-columns: 1fr;
  margin-left: auto;
  margin-right: auto;
  max-width: 250px;
  padding: 48px 0;
  ul {
    margin: 0;
    padding: 0;
    list-style-type: none;
    font-size: 16px;
    li {
      margin-bottom: 4px;
    }
  }
  img {
    height: auto;
    max-width: 100%;
  }
  @media (min-width: 576px) {
    grid-template-columns: 1fr 1fr;
    margin: 0;
    max-width: none;
  }
`

const TotalValueLocked = styled.div`
  padding: 20px;
`

const HeadingLabel = styled.div`
  color: ${({theme}) => theme.colors.text};
  font-size: 18px;
`
const HeadingValue = styled.div`
  // font-family: 
  color: #0084ff;
  padding-top: 10px;
  font-size: 30px;
`

const PoolCardsContainer = styled.div`
  align-items: stretch;
  justify-content: stretch;
  margin-bottom: 48px;
  max-width: 1140px;
  margin: 0 auto;

  & > div {
    width: 100%;
    margin: 20px auto;
  }
`;

const ToggleWrapper = styled.div`
  background: transparent;
  display: flex;
  align-items: center;
  margin-left: 10px;
  ${Text} {
    margin-left: 8px;
  }
  @media (max-width: 768px) {
    width: min-content;
    margin: 10px auto;
  }
`

const LabelWrapper = styled.div`
  display: flex;
  margin: 10px;
`

const FilterContainer = styled.div`
  display: flex;
  justify-content: flex-end;

  @media (max-width: 768px) {
    display: block;
    margin: 0px 15px;
    padding: 0;
  }
`

const ViewControls = styled.div`
  flex-wrap: wrap;
  justify-content: space-between;
  display: flex;
  align-items: center;
  margin: 10px;

  @media (max-width: 768px) {
    text-align: center;
    justify-content: flex-start;
    display: block;
    width: auto;
    > div {
      padding: 0;
      
    }
  }
`

export default Farm
