import React from 'react'
import styled from 'styled-components'
import TradingViewWidget, { Themes } from 'react-tradingview-widget';

const StyledDiv = styled.div`
`
const Chart: React.FC = () => {
  return (
    <StyledDiv>
      <TradingViewWidget
        symbol="KRAKEN:ADAUSD"
        theme={Themes.DARK}
        locale="en"
        autosize
        interval={1}
      />
    </StyledDiv>
  )
}
export default Chart