import React, { useCallback, useEffect, useState } from 'react'
import styled from 'styled-components'
import { Route,  Link, useRouteMatch } from 'react-router-dom'
import { useDispatch } from 'react-redux'
import BigNumber from 'bignumber.js'
import { useWallet } from '@binance-chain/bsc-use-wallet'
import { provider } from 'web3-core'
import { ButtonMenu, ButtonMenuItem,Toggle,Text } from '@pancakeswap-libs/uikit'
import { BLOCKS_PER_YEAR } from 'config'
import Page from 'components/layout/Page'
import Select, { OptionProps } from 'components/Select/Select'
import { useFarms, usePriceBnbBusd, usePriceCakeBusd } from 'state/hooks'
import useRefresh from 'hooks/useRefresh'
import { fetchFarmUserDataAsync } from 'state/actions'
import { QuoteToken } from 'config/constants/types'
import FarmCard, { FarmWithStakedValue } from './components/FarmCard/FarmCard'

export interface FarmsProps{
  tokenMode?: boolean
}

const FarmCards = styled.div`
  align-items: stretch;
  justify-content: stretch;
  margin-bottom: 48px;
  max-width: 1140px;
  margin: 0 auto;

  & > div {
    width: 100%;
    margin: 20px auto;
  }
`
const ControlContainer = styled.div`
  display: flex;
  width: 100%;
  align-items: center;
  position: relative;

  justify-content: space-between;
  flex-direction: column;
  margin-bottom: 32px;

  ${({ theme }) => theme.mediaQueries.sm} {
    flex-direction: row;
    flex-wrap: wrap;
    padding: 16px 32px;
    margin-bottom: 0;
  }
  @media (max-width: 676px) {
    display: block;
  }
`
const PageHeader = styled.div`
  background: transparent;
  display: flex;
`
const HeadingLabel = styled.div`
  color: ${({theme}) => theme.colors.text};
  font-size: 18px;
`
const HeadingValue = styled.div`
  // font-family: 
  color: #0084ff;
  padding-top: 10px;
  font-size: 30px;
`
const ToggleWrapper = styled.div`
  background: transparent;
  display: flex;
  align-items: center;
  margin-left: 10px;
  ${Text} {
    margin-left: 8px;
  }
  @media (max-width: 676px) {
    width: min-content;
    margin: 10px auto;
  }
`

const LabelWrapper = styled.div`
  display: flex;
  margin: 10px 10px;
`

const FilterContainer = styled.div`
  display: flex;
  align-items: center;
  padding: 8px 0px;

  @media (max-width: 676px) {
    display: block;
    margin: 10px auto;
    padding: 0;
  }
`

const ViewControls = styled.div`
  flex-wrap: wrap;
  justify-content: space-between;
  display: flex;
  align-items: center;

  @media (max-width: 676px) {
    text-align: center;
    justify-content: flex-start;
    display: block;
    width: auto;
    > div {
      padding: 0;
      
    }
  }
`

const Farms: React.FC<FarmsProps> = (farmsProps) => {
  const { url, isExact } = useRouteMatch()
  const { path } = useRouteMatch()
  const farmsLP = useFarms()
  const cakePrice = usePriceCakeBusd()
  const bnbPrice = usePriceBnbBusd()
  const { account, ethereum }: { account: string; ethereum: provider } = useWallet()
  const {tokenMode} = farmsProps;

  const [typeOption, setTypeOption] = useState('all')
  const [rewardOption] = useState('all')
  const dispatch = useDispatch()
  const { fastRefresh } = useRefresh()
  useEffect(() => {
    if (account) {
      dispatch(fetchFarmUserDataAsync(account))
    }
  }, [account, dispatch, fastRefresh])

  const [stakedOnly, setStakedOnly] = useState(false)  
   


  // This function compute the APY for each farm and will be replaced when we have a reliable API
  // to retrieve assets prices against USD
  const farmsList = useCallback(
    (farmsToDisplay, removed: boolean) => {
      // const cakePriceVsBNB = new BigNumber(farmsLP.find((farm) => farm.pid === CAKE_POOL_PID)?.tokenPriceVsQuote || 0)
      const farmsToDisplayWithAPY: FarmWithStakedValue[] = farmsToDisplay.map((farm) => {
        // if (!farm.tokenAmount || !farm.lpTotalInQuoteToken || !farm.lpTotalInQuoteToken) {
        //   return farm
        // }
        const cakeRewardPerBlock = new BigNumber(farm.Helium3PerBlock || 1).times(new BigNumber(farm.poolWeight)) .div(new BigNumber(10).pow(18))
        const cakeRewardPerYear = cakeRewardPerBlock.times(BLOCKS_PER_YEAR)

        let apy = cakePrice.times(cakeRewardPerYear);

        let totalValue = new BigNumber(farm.lpTotalInQuoteToken || 0);

        if (farm.quoteTokenSymbol === QuoteToken.BNB) {
          totalValue = totalValue.times(bnbPrice);
        }

        if(totalValue.comparedTo(0) > 0){
          apy = apy.div(totalValue);
        }

        return { ...farm, apy }
      })
      return farmsToDisplayWithAPY.map((farm) => (
        <FarmCard
          key={farm.pid}
          farm={farm}
          removed={removed}
          bnbPrice={bnbPrice}
          cakePrice={cakePrice}
          ethereum={ethereum}
          account={account}
        />
      ))
    },
    [bnbPrice, account, cakePrice, ethereum],
  )
  const renderContent = (): JSX.Element => {
    let activeFarms = []
    if(typeOption==='all')
      activeFarms = farmsLP.filter((farm) =>rewardOption==='all' ? farm.multiplier !== '0X':farm.multiplier !== '0X'&& farm.tokenSymbol===rewardOption)
    if(typeOption==='farm')
      activeFarms = farmsLP.filter((farm) =>rewardOption==='all' ? !!farm.isTokenOnly === !!tokenMode && farm.multiplier !== '0X' : !!farm.isTokenOnly === !!tokenMode && farm.multiplier !== '0X' && farm.tokenSymbol===rewardOption)
    if(typeOption==='single')
      activeFarms = farmsLP.filter((farm) =>rewardOption==='all' ? !!farm.isTokenOnly === true && farm.multiplier !== '0X' : !!farm.isTokenOnly === true && farm.multiplier !== '0X' && farm.tokenSymbol===rewardOption)

    const inactiveFarms = farmsLP.filter((farm) => farm.multiplier === '0X')

    const stakedOnlyFarms = activeFarms.filter(
      (farm) => farm.userData && new BigNumber(farm.userData.stakedBalance).isGreaterThan(0),
    )    
    return (
      <>
      <Route exact path={`${path}`}>
        {stakedOnly ? farmsList(stakedOnlyFarms, false) : farmsList(activeFarms, false)}
      </Route>
      <Route exact path={`${path}/history`}>
        {farmsList(inactiveFarms, true)}
      </Route>
      </>
    )
  }
  const handleTypeOptionChange = (option: OptionProps): void => {
    setTypeOption(option.value)
  }  

  return (
    <Page>
      <div style={{marginTop: "30px"}}>        
        <FarmCards>
          <PageHeader>
            {/* <div style={{display:"inline-block"}}>
              <img src="/images/icon1.png" alt="img" style={{width:"80px"}}/>
            </div> */}
            <div style={{paddingLeft:"20px",display:"inline-block"}}>
              <HeadingLabel>
                TOTAL VALUE LOCKED
              </HeadingLabel>
              <HeadingValue>
                $0
              </HeadingValue>
            </div>
          </PageHeader>
          <ControlContainer> 
            <ViewControls>
              <ButtonMenu activeIndex={isExact ? 0 : 1} size="sm" variant="primary">
                <ButtonMenuItem as={Link} to={`${url}`}>
                  Active
                </ButtonMenuItem>
                <ButtonMenuItem as={Link} to={`${url}/history`}>
                {/* <ButtonMenuItem as={Link} > */}
                  Inactive
                </ButtonMenuItem>
              </ButtonMenu>
              <ToggleWrapper>
                <Toggle checked={stakedOnly} onChange={() => setStakedOnly(!stakedOnly)} />
                <Text> Deposited</Text>
              </ToggleWrapper>
            </ViewControls>
            <FilterContainer>
              <LabelWrapper>
                <Text style={{margin: "auto 10px"}}>Type</Text>
                <Select
                  options={[
                    {
                      label: "All",
                      value: 'all',
                    },
                    {
                      label: 'Farm',
                      value: 'farm',
                    },
                    {
                      label: 'Single Asset',
                      value: 'single',
                    }
                  ]}
                  onChange={handleTypeOptionChange}
                />
              </LabelWrapper>            
            </FilterContainer>
          </ControlContainer>
          {renderContent()}
        </FarmCards>
      </div>
    </Page>
  )
}

export default Farms
