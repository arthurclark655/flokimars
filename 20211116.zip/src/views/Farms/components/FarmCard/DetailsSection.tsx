import React from 'react'
import BigNumber from 'bignumber.js'
import useI18n from 'hooks/useI18n'
import styled from 'styled-components'
import { Flex, Link, LinkExternal, Text } from '@pancakeswap-libs/uikit'
import { provider } from 'web3-core'
import getLiquidityUrlPathParts from 'utils/getLiquidityUrlPathParts'
import { Farm } from 'state/types'
import { Address } from 'config/constants/types'
import CardActionsContainer from './CardActionsContainer'

export interface FarmWithStakedValue extends Farm {
  apy?: BigNumber
}
export interface ExpandableSectionProps {
  isTokenOnly?: boolean
  bscScanAddress?: string
  removed?: boolean
  totalValueFormated?: string
  lpLabel?: string
  quoteTokenAdresses?: Address
  quoteTokenSymbol?: string
  tokenAddresses: Address
  farm: FarmWithStakedValue
  ethereum?: provider
  account?: string
}

const Wrapper = styled.div`
  border-top: 0.5px solid ${({theme}) => theme.colors.textDisabled};
  margin: 24px 150px;
  @media (max-width:676px){
    margin: 14px 10px;
  }

`

const StyledLinkExternal = styled(LinkExternal)`
  text-decoration: none;
  font-weight: normal;
  color: ${({ theme }) => theme.colors.text};
  display: flex;
  align-items: center;

  svg {
    padding-left: 4px;
    height: 18px;
    width: auto;
    fill: ${({ theme }) => theme.colors.textSubtle};
  }
`

const DetailsSection: React.FC<ExpandableSectionProps> = ({
  isTokenOnly,
  bscScanAddress,
  removed,
  totalValueFormated,
  lpLabel,
  quoteTokenAdresses,
  quoteTokenSymbol,
  tokenAddresses,
  farm,
  ethereum,
  account,
}) => {
  const TranslateString = useI18n()
  const liquidityUrlPathParts = getLiquidityUrlPathParts({ quoteTokenAdresses, quoteTokenSymbol, tokenAddresses })

  return (
    <Wrapper>
      <CardActionsContainer farm={farm} ethereum={ethereum} account={account} />
      <Flex justifyContent="space-between">
        <Text> Stake </Text>
        <StyledLinkExternal href={
          isTokenOnly ?
            // `https://exchange.pancakeswap.finance/#/swap/${tokenAddresses[process.env.REACT_APP_CHAIN_ID]}`
            `https://exchange.pancakeswap.finance/#/swap/`
            :
          // `https://exchange.pancakeswap.finance/#/add/${liquidityUrlPathParts}`
          `https://exchange.pancakeswap.finance/#/add/`
        }>
          ${lpLabel}
        </StyledLinkExternal>
      </Flex>
      {!removed && (
        <Flex justifyContent="space-between">
          <Text>{TranslateString(23, 'Total Liquidity')}:</Text>
          {/* <Text>{totalValueFormated === "$NaN"?"$0":totalValueFormated}</Text> */}
          <Text>$0</Text>
        </Flex>
      )}
      <Flex justifyContent="center">
        <Link external 
        // href={bscScanAddress} 
        href='https://www.'
        bold={false}>
          <Text>{TranslateString(356, 'View on BscScan')}</Text>
        </Link>
      </Flex>
    </Wrapper>
  )
}

export default DetailsSection
