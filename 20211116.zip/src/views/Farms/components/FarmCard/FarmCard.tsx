import React, { useMemo, useState } from 'react'
import BigNumber from 'bignumber.js'
import styled from 'styled-components'
import { Flex, Skeleton} from '@pancakeswap-libs/uikit'
import { Farm } from 'state/types'
import { provider } from 'web3-core'
import ExpandableSectionButton from 'components/ExpandableSectionButton'
import { QuoteToken } from 'config/constants/types'
import DetailsSection from './DetailsSection'

export interface FarmWithStakedValue extends Farm {
  apy?: BigNumber
}

const FCard = styled.div`
  border: 1px solid ${({ theme }) => theme.colors.primary};
  border-radius: 5px;
  align-self: baseline;  
  background: ${({ theme }) => theme.colors.card};
  padding: 8px 10px;
  position: relative;
  text-align: center;
`
const FWrapper = styled.div`
  cursor: pointer;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  ${({ theme }) => theme.mediaQueries.sm}{
    background-size: 100% 485px;
  }
  ${({ theme }) => theme.mediaQueries.xs} {
    background-size: 100% 510px;
  }
  text-align: center;
`
const IndicatorIcon = styled.div`
  position: absolute;
  top: -13px;
`

const EarnInfo = styled.div`
  // width: 30%;
  display: flex;
  @media (min-width: 768px){
    min-width: 300px;
  }
  @media (max-width: 768px) {
    flex-direction: column;
  }
`
const LPImage = styled.div`
  margin: auto;
  padding: 0px 10px;
  > img {
    height:40px;
    // width:40px;
  }
`
const EarnInfoText = styled.div`
  display: flex;
  flex-direction: column;

`
const LPLabel = styled.div`
  font-size: 23px;
  text-align: left;
  // color:${({theme}) => theme.colors.text}
  color:#FFFFFF;
`
const EarnLabel = styled.div`
  margin-top:15px;
  text-align: left;
  // color:${({theme}) => theme.colors.textDisabled}
  color:#ffa200;
`
const AprTvl = styled.div`
  width: 30%;
  display: flex;
  flex-direction: row;
  @media (max-width: 768px) {
    width: auto;
    display: block;
    flex-direction: column;
    margin-top: 30px;
    text-align: left;
  }
`
const APRInfo = styled.div`
  display: flex;
  flex-direction: column;
  flex: 1 1 0%;
  margin-left: auto;
  text-align: left;
  @media (max-width: 768px) {
    flex-direction: row;
  }
`
const TVLInfo = styled.div`
  display: flex;
  flex-direction: column;
  flex: 1 1 0%;
  margin-left: auto;
  text-align: left;
  @media (max-width: 768px) {
    flex-direction: row;
    margin-top:20px;
  }
`
const InfoLabel = styled.div`
  font-size: 18px;
  color:${({theme}) => theme.colors.primary};
  text-align: left;
  @media (max-width: 768px) {
    margin-right: 10px;
  }
`
const InfoValue = styled.div`
  margin-top:15px;
  color:${({theme}) => theme.colors.text};
  text-align: left;
  @media (max-width: 768px) {
    margin-top:2px;
  }
`
const ExpandingWrapper = styled.div<{ expanded: boolean }>`
  
  height: ${(props) => (props.expanded ? '100%' : '0px')};
  overflow: hidden;
`


interface FarmCardProps {
  farm: FarmWithStakedValue
  removed: boolean
  cakePrice?: BigNumber
  bnbPrice?: BigNumber
  ethereum?: provider
  account?: string
}

const FarmCard: React.FC<FarmCardProps> = ({ farm, removed, cakePrice, bnbPrice, ethereum, account }) => {
  const [showExpandableSection, setShowExpandableSection] = useState(false)

  // const isCommunityFarm = communityFarms.includes(farm.tokenSymbol)
  // We assume the token name is coin pair + lp e.g. CAKE-BNB LP, LINK-BNB LP,
  // NAR-CAKE LP. The images should be cake-bnb.svg, link-bnb.svg, nar-cake.svg
  // const farmImage = farm.lpSymbol.split(' ')[0].toLocaleLowerCase()
  const farmImage = farm.isTokenOnly ? farm.tokenSymbol.toLowerCase() : `${farm.tokenSymbol.toLowerCase()}-${farm.quoteTokenSymbol.toLowerCase()}`
  // const typeImage = farm.isTokenOnly ? 'single' : 'farm'
  const typeImage = farm.pid
  const totalValue: BigNumber = useMemo(() => {
    if (!farm.lpTotalInQuoteToken) {
      return null
    }
    if (farm.quoteTokenSymbol === QuoteToken.BNB) {
      return bnbPrice.times(farm.lpTotalInQuoteToken)
    }
    if (farm.quoteTokenSymbol === QuoteToken.CAKE) {
      return cakePrice.times(farm.lpTotalInQuoteToken)
    }
    return farm.lpTotalInQuoteToken
  }, [bnbPrice, cakePrice, farm.lpTotalInQuoteToken, farm.quoteTokenSymbol])

  const totalValueFormated = totalValue
    ? `$${Number(totalValue).toLocaleString(undefined, { maximumFractionDigits: 0 })}`
    : '-'

  const lpLabel = farm.lpSymbol

  const { quoteTokenAdresses, quoteTokenSymbol, tokenAddresses } = farm

  return (
    <FCard>
      <FWrapper onClick={() => setShowExpandableSection(!showExpandableSection)}>
        <IndicatorIcon>
          <img src={`images/${typeImage}.png`} alt={`${typeImage}`} style={{height:"25px"}}/>
        </IndicatorIcon>
        <EarnInfo>
          <Flex>
            <LPImage>
              <img src={`/images/farms/${farmImage}.png`} alt={farm.tokenSymbol} />
            </LPImage>
            <div>
            <img src='/images/arrowIcon.png' alt={farm.tokenSymbol} style={{height:"50px"}}/>
            </div>
            <LPImage>
              <img src='/images/bladeIcon.png' alt={farm.tokenSymbol} />
            </LPImage>
          </Flex>
          <EarnInfoText>
            <LPLabel>Stake ${lpLabel}</LPLabel>
            {/* <EarnLabel>Earn {earnLabel}</EarnLabel> */}
            <EarnLabel>Earn $FLOKIMARS</EarnLabel>
          </EarnInfoText>
        </EarnInfo>
        <AprTvl>
          <APRInfo>
            <InfoLabel>APR</InfoLabel>
            <InfoValue>{farm.apy ? (
                  <>
                    {/* {farmAPY}% */}
                    0%
                  </>
                ) : (
                  <Skeleton height={24} width={80} />
                )}
            </InfoValue>
          </APRInfo>
          <TVLInfo>
            <InfoLabel>TVL</InfoLabel>
            <InfoValue>{totalValueFormated ? (
                  <>
                    {/* {totalValueFormated} */}
                    $0
                  </>
                ) : (
                  <Skeleton height={24} width={80} />
                )}
            </InfoValue>
          </TVLInfo>
        </AprTvl>
        <ExpandableSectionButton
          onClick={() => setShowExpandableSection(!showExpandableSection)}
          expanded={showExpandableSection}
        />
      </FWrapper>
      <ExpandingWrapper expanded={showExpandableSection}>
         <DetailsSection
          removed={removed}
          isTokenOnly={farm.isTokenOnly}
          bscScanAddress={
            farm.isTokenOnly ?
              `https://bscscan.com/token/${farm.tokenAddresses[process.env.REACT_APP_CHAIN_ID]}`
              :
              `https://bscscan.com/token/${farm.lpAddresses[process.env.REACT_APP_CHAIN_ID]}`
          }
          totalValueFormated={totalValueFormated}
          lpLabel={lpLabel}
          quoteTokenAdresses={quoteTokenAdresses}
          quoteTokenSymbol={quoteTokenSymbol}
          tokenAddresses={tokenAddresses}
          farm={farm}
          ethereum={ethereum}
          account={account}
        />
      </ExpandingWrapper>
    </FCard>
  )
}

export default FarmCard
