import React from 'react'
import { Card, CardBody, Heading, Text } from '@pancakeswap-libs/uikit'
import BigNumber from 'bignumber.js/bignumber'
import styled from 'styled-components'
import { getBalanceNumber } from 'utils/formatBalance'
import {
  useBurnedBalance,
  useMaxTxAmount,
  useTotalLockedRewards,
  useTotalSupply,
  useTransferTax,
} from 'hooks/useTokenBalance'
import useI18n from 'hooks/useI18n'
import { getCakeAddress } from 'utils/addressHelpers'
import CardValue from './CardValue'
import { useFarms, usePriceCakeBusd } from '../../../state/hooks'
import TotalValueLockedChart from './TVLChart'

const StyledCakeStats = styled(Card)`
  // grid-row-start: 2;
  // grid-row-end: 4;
  display: block;
  text-align: center;
  height: auto !important;
  border-radius: 10px;
  ${({ theme }) => theme.mediaQueries.sm} {
    height: max-content;
    margin-top: 50px;
  }
  `
const StatsContent = styled.div`
  display: grid;
  grid-template-columns: 50% 50%; 
`
const Row = styled.div`
  align-items: center;
  display: flex;
  font-size: 14px;
  justify-content: space-between;
  margin-bottom: 8px;  
  margin-right: 15px;
  margin-left: 15px;
`
const BladePrice = styled.div`
  display: flex;
  margin-right: 24px;

`
const BladeStats = () => {
  const TranslateString = useI18n()
  const totalSupply = useTotalSupply()
  const burnedBalance = useBurnedBalance(getCakeAddress())
  const totalLockedRewards = useTotalLockedRewards()
  const maxTxAmount = useMaxTxAmount()
  const transferTax = useTransferTax()
  const transferTaxvalue = (getBalanceNumber(transferTax))*100000000000000000
  const farms = useFarms();
  const eggPrice = usePriceCakeBusd();
  const circSupply = totalSupply ? totalSupply.minus(burnedBalance) : new BigNumber(0);
  const cakeSupply = getBalanceNumber(circSupply);
  const marketCap = eggPrice.times(circSupply);

  let Helium3PerBlock = 0;
  if(farms && farms[0] && farms[0].Helium3PerBlock){
    Helium3PerBlock = new BigNumber(farms[0].Helium3PerBlock).div(new BigNumber(10).pow(18)).toNumber();
  }

  return (
    <StyledCakeStats>
      <div style={{display: "flex", flexDirection: "row",justifyContent: "space-between",margin: '20px'}}>
        <div style={{display:"flex"}}>
          <img src="images/egg/blade.png" alt="blade" width="26"/> 
          <Heading size="lg" color="#a4cdff" style={{marginLeft:"10px"}}>
            BLADE
          </Heading>
        </div>
        <BladePrice>
          <Text fontSize="14px" color="rgb(127, 132, 180)">Price</Text> <Text color="#00ff36" fontSize="14px"  style={{marginLeft:"10px"}}> $ 1.00</Text>
        </BladePrice>
      </div>
      <StatsContent>
        <CardBody style={{margin: "60px 10px 0px 0px",padding: "5px"}}>
          <Row>
            <Text fontSize="14px" color="rgb(127, 132, 180)">Market Cap</Text>
            <CardValue fontSize="14px" 
            // value={getBalanceNumber(marketCap)} 
            value={0} 
            decimals={0} prefix="$" />
          </Row>
          <Row>
            <Text fontSize="14px" color="rgb(127, 132, 180)">Supply</Text>
            {cakeSupply && <CardValue fontSize="14px" 
            // value={cakeSupply} 
            value={0} 
            decimals={0} />}
          </Row>
        </CardBody>
        <CardBody style={{padding: "0px 10px",paddingBottom: "5px"}}>
          <TotalValueLockedChart/>
        </CardBody>
      </StatsContent>
    </StyledCakeStats>
  )
}

export default BladeStats
