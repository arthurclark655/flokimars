import React from 'react'
import styled, { ThemeContext } from 'styled-components'
import { Card, CardBody, Heading } from '@pancakeswap-libs/uikit'
import { useGetPrice } from 'hooks/api'
import { useFlokimarsLPBnbamount, useFlokimarsLPTokenamount } from 'hooks/useTokenBalance'
import { useTotalValue } from '../../../state/hooks'



const StyledTotalValueLockedCard = styled(Card)`
  //grid-row-start: 1;
  //grid-row-end: 3; 
  text-align: center;
  border-radius: 10px;

  ${({ theme }) => theme.mediaQueries.lg} {
    max-width: none;
  }
`

const CardHeader = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  margin-bottom: 50px;
  @media (max-width:676px){
    flex-direction: row;
  }
`


const VlaueGroup = styled.div`
  display: flex;
  flex-direction: column;
  margin-left: 15px;
  @media (max-width:676px){
    flex-direction: column;
  }
`

const ValuePair = styled.div`
  display: flex;
  flex-direction: row;
  margin-bottom:25px;
  @media (max-width:676px){
    flex-direction: row;
  }
`

const ValueTitle = styled.div`
  display: flex;
  color: #575e8f;
  font-size: 20px;
  font-family: "Poppins-Medium";
  margin-right: 20px;
  @media (max-width:676px){
    flex-direction: row;
    font-size: 15px;
  }
`

const ValueNumber = styled.div`
  display: flex;
  font-size: 20px;
  font-family: "Poppins-Medium";
  @media (max-width:676px){
    flex-direction: row;
    font-size: 15px;
  }
`



const EarnAssetCard: React.FC = () => {

  // const TranslateString = useI18n()
  // const data = useGetStats()
  const totalValue = useTotalValue();
  // const tvl = totalValue.toFixed(2);

  const bnbprice = useGetPrice()
  const price = bnbprice === null? 0:bnbprice.price

  const lpBnb = useFlokimarsLPBnbamount();  
  const lpBnbamount = lpBnb.toNumber()

  const lpFlokimars = useFlokimarsLPTokenamount();  
  const lpFlokimarsamount = lpFlokimars.toNumber()

  const flokimarsPrice = lpBnbamount*price/lpFlokimarsamount;


  return (
    <StyledTotalValueLockedCard>
      <CardBody>
        <CardHeader>
          <img src="images/flokimarsIcon.png" alt="flokimars" style={{marginRight:"10px"}}/>
          <Heading color="text" size="lg" style={{textAlign: "left", color:"#a4cdff"}}>
            $FLOKIMARS TOKEN
          </Heading>          
        </CardHeader>        
        <VlaueGroup>          
          <ValuePair>
            <ValueTitle>
              Price
            </ValueTitle>
            <ValueNumber>
              ${flokimarsPrice.toFixed(15)}
            </ValueNumber>            
          </ValuePair>
          <ValuePair>
            <ValueTitle>
              Supply
            </ValueTitle>
            <ValueNumber>
              1,000,000,000,000,000
            </ValueNumber>            
          </ValuePair>
          <ValuePair>
            <ValueTitle>
              Market cap
            </ValueTitle>
            <ValueNumber>
            ${(flokimarsPrice*(10**15-79.72*10**12)).toFixed(3)}
            </ValueNumber>            
          </ValuePair>          
        </VlaueGroup>
	    </CardBody>
    </StyledTotalValueLockedCard>
  )
}

export default EarnAssetCard
