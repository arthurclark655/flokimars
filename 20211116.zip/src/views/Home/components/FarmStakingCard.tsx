import React, { useCallback, useState } from 'react'
import styled from 'styled-components'
import { Button, Card, CardBody, Heading } from '@pancakeswap-libs/uikit'
import { useWallet } from '@binance-chain/bsc-use-wallet'
import BigNumber from 'bignumber.js'
import useI18n from 'hooks/useI18n'
import { useAllHarvest } from 'hooks/useHarvest'
import useFarmsWithBalance from 'hooks/useFarmsWithBalance'
import UnlockButton from 'components/UnlockButton'
import { useFlokimarsLPBnbamount, useFlokimarsLPTokenamount } from 'hooks/useTokenBalance'
import { useGetPrice } from 'hooks/api'
import CakeHarvestBalance from './CakeHarvestBalance'
import CakeWalletBalance from './CakeWalletBalance'
import { usePriceCakeBusd } from '../../../state/hooks'
import useTokenBalance from '../../../hooks/useTokenBalance'
import { getCakeAddress } from '../../../utils/addressHelpers'
import useAllEarnings from '../../../hooks/useAllEarnings'
import { getBalanceNumber } from '../../../utils/formatBalance'

const StyledFarmStakingCard = styled(Card)`
  // background-image: url('/images/bladeLarge.png');
  background-repeat: no-repeat;
  // background-position: center right;
  background-position: 80% 50%;
  min-height: 376px;
  text-align: left;
  height: max-content;
  border-radius: 10px;
  @media (max-width: 968px) {
    background-size: 50%;
  }
`

const Block = styled.div`
  margin-top: 1em;
  text-align: center;
`

const CardImage = styled.img`
  // box-shadow: -10px 10px 0 0 #d69f42;
  border-radius: 50%;
  margin-top: 5px;
`

const Label = styled.div`
  color: #ef7d00;
  font-size: 16px;
`
const Text = styled.div`
  color: ${({ theme }) => theme.colors.text};
  font-size: 16px;
`

const Actions = styled.div`
  width: 100%;
  text-align: center;
  padding-top: 1em;
`

const Row = styled.div`
  display: flex;
  flex-direction: row;
`
const BlockGroup = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: space-around;
  margin: 20px;
  @media( max-width:676px){
    flex-direction: column;
  }
`

const FarmedStakingCard = () => {
  const [pendingTx, setPendingTx] = useState(false)
  const { account } = useWallet()
  const TranslateString = useI18n()
  const farmsWithBalance = useFarmsWithBalance()
  const cakeBalance = getBalanceNumber(useTokenBalance(getCakeAddress()))
  
  // const bnbprice = useGetPrice()
  // const price = bnbprice === null? 0:bnbprice.price

  // const lpBnb = useFlokimarsLPBnbamount();  
  // const lpBnbamount = lpBnb.toNumber()

  // const lpFlokimars = useFlokimarsLPTokenamount();  
  // const lpFlokimarsamount = lpFlokimars.toNumber()

  // const flokimarsPrice = lpBnbamount*price/lpFlokimarsamount;

  // const balancePrice = flokimarsPrice*cakeBalance;


  const allEarnings = useAllEarnings()
  const earningsSum = allEarnings.reduce((accum, earning) => {
    return accum + new BigNumber(earning).div(new BigNumber(10).pow(18)).toNumber()
  }, 0)
  const balancesWithValue = farmsWithBalance.filter((balanceType) => balanceType.balance.toNumber() > 0)

  const { onReward } = useAllHarvest(balancesWithValue.map((farmWithBalance) => farmWithBalance.pid))

  const harvestAllFarms = useCallback(async () => {
    setPendingTx(true)
    try {
      await onReward()
    } catch (error) {
      // TODO: find a way to handle when the user rejects transaction or it fails
    } finally {
      setPendingTx(false)
    }
  }, [onReward])

  return (
    <StyledFarmStakingCard>
      <CardBody>
        <Heading size="lg" mb="24px" style={{ marginTop: '10px',textAlign: "center", marginBottom: '40px' }} color="#a4cdff">
          Staking
        </Heading>
        <BlockGroup>
          {/* <Block>
            <img src="/images/flokimarsIcon.png" alt="FLOKIMARS" style={{ margin: "0em auto 1em auto" }} width="70"/>
              <Label>$FLOKIMARS to Harvest</Label>
              <CakeHarvestBalance 
              // earningsSum={earningsSum}
              earningsSum={0}
              />
            {/* <Row>
              <Text>~${(eggPrice * earningsSum).toFixed(2)}</Text>
            </Row> 
          </Block> */}
          <Block>
            <img src="/images/flokimarsIcon.png" alt="FLOKIMARS" style={{ margin: "0em auto 1em auto" }} width="70"/>
              <Label>$FLOKIMARS in Wallet</Label>
              <CakeWalletBalance 
              cakeBalance={cakeBalance.toFixed(2)} 
              // cakeBalance={0} 
              />
            {/* <Row>
              <Text>~${(eggPrice * cakeBalance).toFixed(2)}</Text>
            </Row> */}
          </Block>
        </BlockGroup>
        <Actions>
          {account ? (
            <Button
              id="harvest-all"
              disabled={balancesWithValue.length <= 0 || pendingTx}
              // onClick={harvestAllFarms}
              fullWidth
            >
              {pendingTx
                ? TranslateString(548, ' FLOKIMARS Token')
                : TranslateString(999, `Harvest All (${balancesWithValue.length})`)}
            </Button>
          ) : (
            <UnlockButton className="imgBtn"/>
          )}
        </Actions>
      </CardBody>
    </StyledFarmStakingCard>
  )
}

export default FarmedStakingCard
