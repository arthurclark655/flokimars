import React, {lazy, useEffect,useState, useContext } from 'react'
import styled, { ThemeContext } from 'styled-components'
import { lotteryHistory } from '../../../api/lottery/lotteryHistory'

const Line = lazy(() => import('./LineChartWrapper'))

const TotalValueLockedChart: React.FC = () => {
  const [historyData, setHistoryData] = useState([])
    useEffect(() => {
        lotteryHistory()
        .then((data) =>{
        setHistoryData(data)
        }
    )
    },[])
    const {colors} = useContext(ThemeContext)
    const getDataArray = (kind) => {
        return historyData
        .map((dataPoint) => {
            return dataPoint[kind]
        })
        .reverse()
    }

  const lineStyles = ({ color }) => {
    return {
      borderColor: color,
      backgroundColor: "transparent",
      fill: false,
      borderWidth: 2,
      pointRadius: 0.5,
      pointHitRadius: 10,
    }
  }

  const chartData = {
    labels: getDataArray('lotteryNumber'),
    datasets: [
      {
        data: getDataArray('poolSize'),
        ...lineStyles({ color: colors.secondary }),
      },
    ],
  }  

  const options = {
    legend: { display: false },
    scales: {
      yAxes: [
        {
          type: 'linear',
          display: false,
          position: 'left',
          id: 'y-axis-pool',
        }
      ],
      xAxes: [
        {
          display: false,
        },
      ],
    },
  }
  return (
    <Line data={chartData} options={options} type="line" />
  )
}

export default TotalValueLockedChart