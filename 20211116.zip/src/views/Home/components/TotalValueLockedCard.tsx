import React from 'react'
import styled, { ThemeContext } from 'styled-components'
import { Card, CardBody, Heading } from '@pancakeswap-libs/uikit'
import { useFlokimarsLPBnbamount, useFlokimarsLPTokenamount } from 'hooks/useTokenBalance'
import { useGetPrice } from 'hooks/api'
import { usePoolValue } from '../../../state/hooks'
import CardValue from './CardValue'
// import useI18n from 'hooks/useI18n'
import TotalValueLockedChart from './TVLChart'

const StyledTotalValueLockedCard = styled(Card)`
  grid-row-start: 1;
  //grid-row-end: 3; 
  text-align: center;
  border-radius: 10px;

  ${({ theme }) => theme.mediaQueries.lg} {
    max-width: none;
  }
`

const CardHeader = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  margin-bottom: 50px;
  @media (max-width:676px){
    flex-direction: column;
  }
`

const CardMidContent = styled(Heading).attrs({ size: 'lg' })`
  display: flex;
  flex-direction: column;
  line-height: 1.1em;
  padding-top: 10px;
  text-align: left;
  > div {
    color:#00ff36 !important;
  }
  @media (max-width:676px){
    flex-direction: column;
  }
`
const TVLVlaue = styled.div`
  display: flex;
  -webkit-box-pack: justify;
  justify-content: center;
  align-items: center;
  margin-top: 15px;
  @media (max-width: 676px){
    flex-direction: column;
  }
`
const TVLInfo = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  @media (max-width:676px){
    flex-direction: column;
  }
`
const TVLIconGroup = styled.div`  
  -webkit-box-pack: center;
  justify-content: center;
  align-items: center;
`

const TVLInfoLable = styled.div`
  font-size: 13px;
  font-weight: 500;
  margin-top: 5px;
  color: #ffffff;
  @media (max-width:676px){
    margin-left: 5px;
    text-align: left;
  }
`
const TVLInfoValue = styled.div`
  margin-top: 13px;
  font-size: 16px;
  font-weight: 500;
  color: #ffffff;
`

const TotalValueLockedCard: React.FC = () => {

  // const TranslateString = useI18n()
  // const data = useGetStats()
  const poolValue0 = usePoolValue(0).toNumber();
  const poolValue1 = usePoolValue(1).toNumber();
  const poolValue2 = usePoolValue(2).toNumber();

  const bnbprice = useGetPrice()
  const price = bnbprice === null? 0:bnbprice.price

  const lpBnb = useFlokimarsLPBnbamount();  
  const lpBnbamount = lpBnb.toNumber()

  const lpFlokimars = useFlokimarsLPTokenamount();  
  const lpFlokimarsamount = lpFlokimars.toNumber()

  const flokimarsPrice = lpBnbamount*price/lpFlokimarsamount;

  const balancePrice = (poolValue0 * flokimarsPrice + poolValue1 * price + poolValue2 * 1)/10**18;
  // console.log("balancePrice", balancePrice)

  return (
    <StyledTotalValueLockedCard>
      <CardBody>
        <CardHeader>
          <Heading color="text" size="lg" style={{textAlign: "left", color:"#a4cdff"}}>
            Total Value Locked
          </Heading>
          <CardMidContent style={{color:"#12ff00"}}>
              ${balancePrice.toFixed(2)}              
          </CardMidContent>
        </CardHeader>
        <div className="TVLChart">
         <TotalValueLockedChart/>
        </div>
        <TVLVlaue>          
          <TVLInfo>
            <TVLIconGroup> 
                <img src="images/flokimarsIcon.png" alt="link" style={{ margin: "0em auto 1em auto" }} width="70"/>
            </TVLIconGroup>            
            <TVLInfoLable>
              $FLOKIMARS on BSC
            </TVLInfoLable>
            {/* <TVLInfoValue>
              $0.00
            </TVLInfoValue>             */}
          </TVLInfo>          
        </TVLVlaue>
	    </CardBody>
    </StyledTotalValueLockedCard>
  )
}

export default TotalValueLockedCard
