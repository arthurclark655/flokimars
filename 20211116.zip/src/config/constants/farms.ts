import contracts from './contracts'
import { FarmConfig, QuoteToken } from './types'

const farms: FarmConfig[] = [
  {
    pid: 0,
    risk: 5,
    lpSymbol: 'ROCKET',
    isTokenOnly: true,
    lpAddresses: {
      97: '',
      56: '0x4Be36eE456c602dC119B763A2F867A3cdCfF0939',
    },
    tokenSymbol: 'BLADE',
    tokenAddresses: {
      97: '',
      56: '0x8d9087a2B7E446bb69343542e1430E974f12a18F',
    },
    quoteTokenSymbol: QuoteToken.BUSD,
    quoteTokenAdresses: contracts.busd,
  },
  // {
  //   pid: 1,
  //   risk: 5,
  //   lpSymbol: 'ROCKET',
  //   lpAddresses: {
  //     97: '',
  //     56: '0xE9bdEDA655699D7176e22C55f06C00461F0e98aF',
  //   },
  //   tokenSymbol: 'BLADE',
  //   tokenAddresses: {
  //     97: '',
  //     56: '0x8d9087a2B7E446bb69343542e1430E974f12a18F',
  //   },
  //   quoteTokenSymbol: QuoteToken.BNB,
  //   quoteTokenAdresses: contracts.wbnb,
  // },
  {
    pid: 2,
    risk: 3,
    lpSymbol: 'BUSD',
    isTokenOnly: true,
    lpAddresses: {
      97: '',
      56: '0x58F876857a02D6762E0101bb5C46A8c1ED44Dc16',
    },
    tokenSymbol: 'BUSD',
    tokenAddresses: {
      97: '',
      56: '0xbb4cdb9cbd36b01bd1cbaebf2de08d9173bc095c',
    },
    quoteTokenSymbol: QuoteToken.BUSD,
    quoteTokenAdresses: contracts.busd,
  },  
  {
    pid: 4,
    risk: 4,
    lpSymbol: 'BNB',
    isTokenOnly: true,
    lpAddresses: {
      97: '',
      56: '0x0eD7e52944161450477ee417DE9Cd3a859b14fD0',
    },
    tokenSymbol: 'HE3',
    tokenAddresses: {
      97: '',
      56: '0x0e09fabb73bd3ade0a17ecc321fd13a19e81ce82',
    },
    quoteTokenSymbol: QuoteToken.BUSD,
    quoteTokenAdresses: contracts.busd,
  },
  // {
  //   pid: 5,
  //   risk: 4,
  //   lpSymbol: 'ROCKET',
  //   lpAddresses: {
  //     97: '',
  //     56: '0x16b9a82891338f9bA80E2D6970FddA79D1eb0daE',
  //   },
  //   tokenSymbol: 'BLADE',
  //   tokenAddresses: {
  //     97: '',
  //     56: '0x55d398326f99059ff775485246999027b3197955',
  //   },
  //   quoteTokenSymbol: QuoteToken.CAKE,
  //   quoteTokenAdresses: contracts.cake,
  // },
  
  
]

export default farms
