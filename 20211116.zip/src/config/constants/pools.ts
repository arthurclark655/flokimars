import { PoolCategory, PoolConfig, QuoteToken } from './types'

const pools: PoolConfig[] = [
  {
    sousId: 0,
    tokenName: 'FLOKIMARS',
    stakingTokenName: QuoteToken.FLOKIMARS,
    stakingTokenAddress: '0x399B091aDfeEe715460e31EF1Ff76FfcFC1eFDa9',
    contractAddress: {
      97: '',
      56: '0x63216ce8F7bFaAE16F1F29e2Fd5B0A2D88E7F00F',
    },
    poolCategory: PoolCategory.CORE,
    projectLink: 'https://pancakeswap.finance/',
    harvest: true,
    tokenPerBlock: '69400000',
    sortOrder: 1,
    isFinished: false,
    tokenDecimals: 18,
    burnFee: 10,
  },
  {
    sousId: 1,
    tokenName: 'FLOKIMARS',
    stakingTokenName: QuoteToken.WBNB,
    stakingTokenAddress: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',
    contractAddress: {
      97: '',
      56: '0x12A0d645A0833Ca7A452D29bAef174D1e4faF3c5',
    },
    poolCategory: PoolCategory.CORE,
    projectLink: 'https://pancakeswap.finance/',
    harvest: true,
    tokenPerBlock: '10',
    sortOrder: 2,
    isFinished: false,
    tokenDecimals: 18,
    burnFee: 10,
  },
  {
    sousId: 2,
    tokenName: 'FLOKIMARS',
    stakingTokenName: QuoteToken.BUSD,
    stakingTokenAddress: '0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56',
    contractAddress: {
      97: '',
      56: '0xf3C7bbd2fb01a7056650B2e0E16Cb7a81F074F4a',
    },
    poolCategory: PoolCategory.CORE,
    projectLink: 'https://pancakeswap.finance/',
    harvest: true,
    tokenPerBlock: '10',
    sortOrder: 3,
    isFinished: false,
    tokenDecimals: 18,
    burnFee: 10,
  },  
]

export default pools
