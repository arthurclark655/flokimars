import addresses from 'config/constants/contracts'

const chainId = process.env.REACT_APP_CHAIN_ID

export const getCakeAddress = () => {
  return addresses.cake[chainId]
}
export const getMasterChefAddress = () => {
  return addresses.masterChef[chainId]
}
export const getGettingtimeAddress = () => {
  return addresses.gettingtime[chainId]
}
export const getMulticallAddress = () => {
  return addresses.mulltiCall[chainId]
}
export const getWbnbAddress = () => {
  return addresses.wbnb[chainId]
}
export const getLotteryAddress = () => {
  return addresses.lottery[chainId]
}
export const getLotteryTicketAddress = () => {
  return addresses.lotteryNFT[chainId]
}
export const getLP1Address = () => {
  return addresses.pancakepair1[chainId]
}
export const getLP2Address = () => {
  return addresses.pancakepair2[chainId]
}
export const getflokimarsLPAddress = () => {
  return addresses.flokimarslp[chainId]
}

