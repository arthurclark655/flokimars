import BigNumber from 'bignumber.js'
import React, { useCallback, useState } from 'react'
import styled from 'styled-components'
import { AddIcon, Button, IconButton, useModal, Flex, Link, Text } from '@pancakeswap-libs/uikit'
import { useWallet } from '@binance-chain/bsc-use-wallet'
import UnlockButton from 'components/UnlockButton'
import Label from 'components/Label'
import { useERC20 } from 'hooks/useContract'
import { useSousApprove } from 'hooks/useApprove'
import useI18n from 'hooks/useI18n'
import { useSousStake } from 'hooks/useStake'
import { useSousUnstake } from 'hooks/useUnstake'
import useBlock from 'hooks/useBlock'
import { getBalanceNumber } from 'utils/formatBalance'
import { useSousHarvest } from 'hooks/useHarvest'
import Balance from 'components/Balance'
import { PoolCategory, QuoteToken } from 'config/constants/types'
import { Pool } from 'state/types'
import ExpandableSectionButton from 'components/ExpandableSectionButton'
import DepositModal from './DepositModal'
import WithdrawModal from './WithdrawModal'
import CompoundModal from './CompoundModal'
import CardTitle from './CardTitle'
import Card from './Card'
import OldSyrupTitle from './OldSyrupTitle'
import HarvestButton from './HarvestButton'
// import CardFooter from './CardFooter'


interface PoolWithApy extends Pool {
  apy: BigNumber
}

interface HarvestProps {
  pool: PoolWithApy
}

const PoolCard: React.FC<HarvestProps> = ({ pool }) => {
  const {
    sousId,
    image,
    tokenName,
    stakingTokenName,
    stakingTokenAddress,
    projectLink,
    harvest,
    apy,
    tokenDecimals,
    poolCategory,
    // totalStaked,
    // startBlock,
    // endBlock,
    isFinished,
    userData,
    stakingLimit,
    burnFee
  } = pool

  const [showExpandableSection, setShowExpandableSection] = useState(false);
  const typeImage = sousId;
  
  // Pools using native BNB behave differently than pools using a token
  const isBnbPool = poolCategory === PoolCategory.BINANCE
  const TranslateString = useI18n()
  const stakingTokenContract = useERC20(stakingTokenAddress)
  const { account } = useWallet()
  // const block = useBlock()
  const { onApprove } = useSousApprove(stakingTokenContract, sousId)
  const { onStake } = useSousStake(sousId, isBnbPool)
  const { onUnstake } = useSousUnstake(sousId)
  const { onReward } = useSousHarvest(sousId, isBnbPool)

  const [requestedApproval, setRequestedApproval] = useState(false)
  const [pendingTx, setPendingTx] = useState(false)

  const allowance = new BigNumber(userData?.allowance || 0)
  const stakingTokenBalance = new BigNumber(userData?.stakingTokenBalance || 0)
  const stakedBalance = new BigNumber(userData?.stakedBalance || 0)
  const earnings = new BigNumber(userData?.pendingReward || 0)

  // const blocksUntilStart = Math.max(startBlock - block, 0)
  // const blocksRemaining = Math.max(endBlock - block, 0)
  const isOldSyrup = stakingTokenName === QuoteToken.SYRUP
  const accountHasStakedBalance = stakedBalance?.toNumber() > 0
  const needsApproval = !accountHasStakedBalance && !allowance.toNumber() && !isBnbPool
  const isCardActive = isFinished && accountHasStakedBalance

  const convertedLimit = new BigNumber(stakingLimit).multipliedBy(new BigNumber(10).pow(tokenDecimals))
  const [onPresentDeposit] = useModal(
    <DepositModal
      max={stakingLimit && stakingTokenBalance.isGreaterThan(convertedLimit) ? convertedLimit : stakingTokenBalance}
      onConfirm={onStake}
      tokenName={stakingLimit ? `${stakingTokenName} (${stakingLimit} max)` : stakingTokenName}
      burnFeeBP={burnFee * 10}
    />,
  )

  const [onPresentCompound] = useModal(
    <CompoundModal earnings={earnings} onConfirm={onStake} tokenName={stakingTokenName} />,
  )

  const [onPresentWithdraw] = useModal(
    <WithdrawModal max={stakedBalance} onConfirm={onUnstake} tokenName={stakingTokenName} />,
  )

  const handleApprove = useCallback(async () => {
    try {
      setRequestedApproval(true)
      const txHash = await onApprove()
      // user rejected tx or didn't go thru
      if (!txHash) {
        setRequestedApproval(false)
      }
    } catch (e) {
      console.error(e)
    }
  }, [onApprove, setRequestedApproval])

  return (
    <Card isActive={isCardActive} isFinished={isFinished && sousId !== 0}>
      <IndicatorIcon>
        <img src={`/images/${typeImage}.png`} alt={`${typeImage}`} style={{height:"25px"}}/>
      </IndicatorIcon>
      {isFinished && sousId !== 0 && <PoolFinishedSash />}     

      <PoolCardHeader onClick={() => setShowExpandableSection(!showExpandableSection)}>
        <div className='w3-row'>
          <div className='w3-col m5'>
            <div style={{display: 'flex', alignItems: 'center'}}>
              <img src={`/images/tokens/${image || tokenName}.png`} style={{width: '50px', height: '50px'}} alt={tokenName} />
              <CardTitle isFinished={isFinished && sousId !== 0}>
                {isOldSyrup && '[OLD]'} {tokenName} {TranslateString(348, 'Pool')}
              </CardTitle>
            </div>              
          </div>
          <div className='w3-col m3 w3-center' >
            <StyledDetails>
              <div className='w3-margin'>{TranslateString(736, 'APR')}:</div>
              {isFinished || isOldSyrup || !apy || apy?.isNaN() || !apy?.isFinite() ? (
                <div className='w3-margin'>-</div>
              ) : (
                <div className='w3-margin'>
                  <Balance fontSize="14px" isDisabled={isFinished} value={apy?.toNumber()} decimals={2} unit="%" />
                </div>                  
              )}
            </StyledDetails>
          </div>
          <div className='w3-col m3'>
            <StyledDetails>
              <div className='w3-margin'>{TranslateString(736, 'TVL')}:</div>
              {isFinished || isOldSyrup || !apy || apy?.isNaN() || !apy?.isFinite() ? (
                <div className='w3-margin'>-</div>
              ) : (
                <div className='w3-margin'>
                  <Balance fontSize="14px" isDisabled={isFinished} value={apy?.toNumber()} decimals={2} unit="%" />
                </div>                  
              )}
            </StyledDetails>
          </div>
          <div className='w3-col m1'>
            <div style={{marginTop: '14px'}}>
              <ExpandableSectionButton 
                onClick={() => setShowExpandableSection(!showExpandableSection)}
                expanded={showExpandableSection}
              />
            </div>              
          </div>
        </div>
      </PoolCardHeader>   

      <ExpandingWrapper expanded={showExpandableSection} className='w3-animate-opacity'>
        <Wrapper>
          <div style={{ marginBottom: '8px', display: 'flex', alignItems: 'center' }}>
            <div style={{ flex: 1 }}>
              {!isOldSyrup ? (
                <BalanceAndCompound>
                  <Balance value={getBalanceNumber(earnings, tokenDecimals)} isDisabled={isFinished} />              
                </BalanceAndCompound>
              ) : (
                <OldSyrupTitle hasBalance={accountHasStakedBalance} />
              )}
            </div>
            {account && harvest && !isOldSyrup && (
              <HarvestButton
                disabled={!earnings.toNumber() || pendingTx}
                text={pendingTx ? 'Collecting' : 'Harvest'}
                onClick={async () => {
                  setPendingTx(true)
                  await onReward()
                  setPendingTx(false)
                }}
              />
            )}
          </div>
          
          <Label isFinished={isFinished && sousId !== 0} text={TranslateString(330, `${tokenName} earned`)} />
          <StyledCardActions>
            {!account && <UnlockButton />}
            {account &&
              (needsApproval && !isOldSyrup ? (
                <div style={{ flex: 1 }}>
                  <Button disabled={isFinished || requestedApproval} onClick={handleApprove} fullWidth>
                    {`Approve ${stakingTokenName}`}
                  </Button>
                </div>
              ) : (
                <>
                  <Button
                    disabled={stakedBalance.eq(new BigNumber(0)) || pendingTx}
                    onClick={
                      isOldSyrup
                        ? async () => {
                            setPendingTx(true)
                            await onUnstake('0')
                            setPendingTx(false)
                          }
                        : onPresentWithdraw
                    }
                  >
                    {`Unstake ${stakingTokenName}`}
                  </Button>
                  <StyledActionSpacer />
                  {!isOldSyrup && (
                    <IconButton disabled={isFinished && sousId !== 0} onClick={onPresentDeposit}>
                      <AddIcon color="background" />
                    </IconButton>
                  )}
                </>
              ))}
          </StyledCardActions>          
          
          <StyledDetails>
            <div style={{ flex: 1 }}>              
              <Text>
                <span role="img" aria-label={stakingTokenName}>
                  🥞{' '}
                </span>
                {TranslateString(384, 'Your Stake')}:
              </Text>
            </div>
            <Balance fontSize="14px" isDisabled={isFinished} value={getBalanceNumber(stakedBalance)} />
          </StyledDetails>
          {!isFinished && (
            <Flex justifyContent="space-between">
              <Text>{TranslateString(23, 'Total Liquidity')}:</Text>
              {/* <Text>{totalValueFormated === "$NaN"?"$0":totalValueFormated}</Text> */}
              <Text>$0</Text>
            </Flex>
          )}
          <Flex justifyContent="center">
            <Link external 
            // href={bscScanAddress} 
            href='https://www.'
            bold={false}>
              <Text>{TranslateString(356, 'View on BscScan')}</Text>
            </Link>
          </Flex>
        </Wrapper>          
      </ExpandingWrapper>                
      
    </Card>
  )
}

const PoolFinishedSash = () => {
 return (
   <PoolFinishedSashDiv>
     <img src='/images/pool-finished-sash.svg' alt='pool-finished' style={{width: '100%'}}/>
   </PoolFinishedSashDiv>
 )
};

const PoolFinishedSashDiv = styled.div`
  height: 90px;
  position: absolute;
  right: -15px;
  top: -15px;
  width: 90px;
`

const StyledCardActions = styled.div`
  display: flex;
  justify-content: center;
  margin: 16px 0;
  width: 100%;
  box-sizing: border-box;
`

const BalanceAndCompound = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-direction: row;
`

const StyledActionSpacer = styled.div`
  height: ${(props) => props.theme.spacing[4]}px;
  width: ${(props) => props.theme.spacing[4]}px;
`

const StyledDetails = styled.div`
  display: flex;
  font-size: 14px;
`

const ExpandingWrapper = styled.div<{ expanded: boolean }>`  
  display: ${(props) => (props.expanded ? 'block' : 'none')};
  overflow: hidden;
  padding: 24px;
  padding-top: 0;
`;

const PoolCardHeader = styled.div`
  padding: 24px;
  cursor: pointer;
`;

const Wrapper = styled.div`
  padding-top: 24px;
  border-top: 0.5px solid ${({theme}) => theme.colors.textDisabled};
  margin: 24px 150px;
  @media (max-width:676px){
    margin: 14px 10px;
  }
`;

const IndicatorIcon = styled.div`
  position: absolute;
  left: 25px;
  top: -13px;
`;

export default PoolCard
